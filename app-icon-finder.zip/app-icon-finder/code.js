var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
figma.showUI(__html__, { width: 300, height: 480, title: "App Icon Finder" });
figma.ui.onmessage = (msg) => __awaiter(this, void 0, void 0, function* () {
    // One way of distinguishing between different types of messages sent from
    // your HTML page is to use an object with a "type" property like this.
    if (msg.type === 'place-icon') {
        for (const selection of figma.currentPage.selection) {
            if ("fills" in selection) {
                const fills = JSON.parse(JSON.stringify(selection.fills));
                fills[0].color.r = 1;
                selection.fills = fills;
            }
        }
    }
    if (msg.type === 'replace-text') {
        for (const selection of figma.currentPage.selection) {
            if ("characters" in selection) {
                const fontName = JSON.parse(JSON.stringify(selection.fontName));
                yield figma.loadFontAsync({ family: fontName.family, style: fontName.style });
                selection.characters = msg.text;
            }
        }
    }
    if (msg.type === 'icon') {
        console.log('msg.iconUrl');
    }
    if (msg.type === 'create-image') {
        for (const selection of figma.currentPage.selection) {
            if ("fills" in selection) {
                const newPaint = {
                    type: "IMAGE",
                    scaleMode: "FILL",
                    imageHash: "",
                    imageTransform: [[1, 0, 0], [0, 1, 0]],
                    filters: { contrast: 0, exposure: 0, highlights: 0, saturation: 0, shadows: 0, temperature: 0, tint: 0 },
                    rotation: 0,
                    scalingFactor: 0.5,
                    visible: true,
                };
                newPaint.imageHash = figma.createImage(msg.data).hash;
                const newFills = [];
                newFills.push(newPaint);
                selection.fills = newFills;
            }
        }
    }
    if (msg.type === 'close') {
        figma.closePlugin();
    }
});
